
from PyQt5 import QtCore, QtGui, QtWidgets
import cv2 ,numpy as np
from sklearn.neighbors import KNeighborsClassifier as knn
import os

class Ui_Dialog(object):
    
    def __init__(self):
        self.my_absolute_dirpath = os.path.abspath(os.path.dirname(__file__))
        
        self.dataset = cv2.CascadeClassifier(self.my_absolute_dirpath+"\\npyFiles\haarcascade_frontalface_default.xml")
        
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(563, 571)
        Dialog.setAutoFillBackground(True)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 10, 481, 61))
        self.label.setLayoutDirection(QtCore.Qt.RightToLeft)
        self.label.setMidLineWidth(8)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(40, 100, 501, 20))
        self.label_2.setObjectName("label_2")
        self.celebrity = QtWidgets.QPushButton(Dialog)
        self.celebrity.setGeometry(QtCore.QRect(30, 240, 161, 41))
        self.celebrity.setObjectName("celebrity")
        self.celebrity.clicked.connect(self.calculate3)
        self.animal = QtWidgets.QPushButton(Dialog)
        self.animal.setGeometry(QtCore.QRect(30, 310, 161, 41))
        self.animal.setObjectName("animal")
        self.animal.clicked.connect(self.calculate)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(340, 160, 211, 41))
        self.label_3.setAutoFillBackground(True)
        self.label_3.setFrameShape(QtWidgets.QFrame.Box)
        self.label_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_3.setObjectName("label_3")
        self.mask = QtWidgets.QPushButton(Dialog)
        self.mask.setGeometry(QtCore.QRect(370, 310, 121, 41))
        
        
        self.mask.setObjectName("mask")
        self.mask.clicked.connect(self.facemask)
        self.cap = QtWidgets.QPushButton(Dialog)
        self.cap.setGeometry(QtCore.QRect(370, 240, 121, 41))
        
        self.cap.setObjectName("cap")
        self.cap.clicked.connect(self.facemask3)
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(10, 160, 231, 41))
        self.label_4.setFrameShape(QtWidgets.QFrame.Box)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(30, 380, 281, 21))
        self.label_5.setObjectName("label_5")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
    def calculate3(self):
        face_10 =  np.load(self.my_absolute_dirpath+'\\npyFiles\JAMES BOND500.npy')
        face_20 =  np.load(self.my_absolute_dirpath+'\\npyFiles\KHALI500.npy')
        face_30 =  np.load(self.my_absolute_dirpath+'\\npyFiles\MICHHAL JACKSON500.npy')
        face_40 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Salman500.npy')  
        face_50 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Hritik500.npy')
        face_60 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Kareena500.npy')
        face_70 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Priyanka500.npy')
       
        face_1 = face_10.reshape(500,-1)
        face_2 = face_20.reshape(500,-1)
        face_3 = face_30.reshape(500,-1)
        face_4 = face_40.reshape(500,-1)
        face_5 = face_50.reshape(500,-1)
        face_6 = face_60.reshape(500,-1)
        face_7 = face_70.reshape(500,-1)
        
        faceData = np.concatenate([face_1,face_2,face_3,face_4,face_5,face_6,face_7])
        
        label = np.zeros((faceData.shape[0],1))
        
        label[500:1000,:] = 1.0
        label[1000:1500,:] = 2.0
        label[1500:2000,:] = 3.0
        label[2000:2500,:] = 4.0
        label[2500:3000,:] = 5.0
        label[3000:3500,:] = 6.0
        
        users={
               0:"jamesBond",
               1:"khali",
               2:"michal Jackson",
               3:"Salman Khan",
               4:"Hritik Rosan",
               5:"Kareena Kapoor",
               6:"Priyanka Chopra"
               
               }
        X,Y = faceData[:,:],label[:,-1]
        model = knn(n_neighbors=5)
        model.fit(X,Y)
       
        capture= cv2.VideoCapture(0) 
        font = cv2.FONT_HERSHEY_COMPLEX
        text = None
        while True:
             ret,img=capture.read()
             if ret:
                  face =self.dataset.detectMultiScale(img,1.1)
                  X_test=[]
                  for x,y,w,h in face:
                       cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),1)
                       target = img[y:y+h,x:x+w,:]
                       target = cv2.resize(target,(50,50))
                       X_test.append(target.reshape(-1))
                      
                       response = model.predict(np.array(X_test))
                       count = np.unique(response,return_counts=True)
                       outcome =count[0][np.argmax(count[1])]
                       #global text
                       text = users[int(outcome)]     
                       cv2.putText(img,text,(x,y+h),font,1,(45,63,88),2)
                       
                  cv2.imshow('Looklikecelebrity',img)
                  if users[0]==text:
                           
                      cv2.imshow("img",cv2.resize(face_10[11],(100,100)))
                  if users[1]==text:
                      cv2.imshow("img",cv2.resize(face_20[11],(100,100)))
                  if users[2]==text:
                      cv2.imshow("img",cv2.resize(face_30[11],(100,100)))
                  if users[3]==text:
                      cv2.imshow("img",cv2.resize(face_40[11],(100,100)))
                  if users[4]==text:
                      cv2.imshow("img",cv2.resize(face_50[11],(100,100)))
                  if   users[5]==text:
                      cv2.imshow("img",cv2.resize(face_60[11],(100,100)))
                  if users[6]==text:
                      cv2.imshow("img",cv2.resize(face_70[11],(100,100)))
                 
             else:
                  capture.set(cv2.CAP_PROP_POS_FRAMES,0)
        
             
             if cv2.waitKey(10)==27:
                  break
        capture.release()
        cv2.destroyAllWindows()

    def calculate(self):
       
        face_11 =  np.load(self.my_absolute_dirpath+'\\npyFiles\simplecatface20.npy')
       
        face_33 =  np.load(self.my_absolute_dirpath+'\\npyFiles\simpledogface20.npy')
        face_44 =  np.load(self.my_absolute_dirpath+'\\npyFiles\simplepigeonface20.npy')
        face_55 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Bear20.npy')
        face_66 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Donkey20.npy')
        face_77 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Fish20.npy')
        face_88 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Lion20.npy')
        face_99 =  np.load(self.my_absolute_dirpath+'\\npyFiles\Turtel20.npy')
        
        face_1 = face_11.reshape(20,-1)
       
        face_3 = face_33.reshape(20,-1)
        face_4 = face_44.reshape(20,-1)
        face_5 = face_55.reshape(20,-1)
        face_6 = face_66.reshape(20,-1)
        face_7 = face_77.reshape(20,-1)
        face_8 = face_88.reshape(20,-1)
        face_9 = face_99.reshape(20,-1)
        
        faceData = np.concatenate([face_1,face_3,face_4,face_5,face_6,face_7,face_8,face_9])
        
        label = np.zeros((faceData.shape[0],1))
        label[20:40,:] = 1.0
        label[40:60,:] = 2.0
        label[60:80,:] = 3.0
        label[80:100,:] = 4.0
        label[100:120,:] = 5.0
        label[120:140,:] = 6.0
        label[140:160,:] = 7.0
    
        
        
        users={
               0:"cat",
               #1:"chimpangi",
               1:"dog",
               2:"pigeon",
               3:"Bear",
               4:"Donkey",
               5:"Fish",
               6:"Lion",
               7:"Turtul"
               }
        X,Y = faceData[:,:],label[:,-1]
        model = knn(n_neighbors=5)
        model.fit(X,Y)
       
        capture= cv2.VideoCapture(0) 
        font = cv2.FONT_HERSHEY_COMPLEX
        text=None
        while True:
             ret,imgOrg=capture.read()
             img = cv2.cvtColor(imgOrg,cv2.COLOR_BGR2GRAY)
             if ret:
                  face =self.dataset.detectMultiScale(img,1.1)
                  
                  X_test=[]
                  for x,y,w,h in face:
                       cv2.rectangle(imgOrg,(x,y),(x+w,y+h),(255,0,0),1)
                       target = img[y:y+h,x:x+w]
                       target = cv2.resize(target,(50,50))
                       X_test.append(target.reshape(-1))
                      
                       response = model.predict(np.array(X_test))
                       count = np.unique(response,return_counts=True)
                       outcome =count[0][np.argmax(count[1])]
                       text = users[int(outcome)]     
                       cv2.putText(imgOrg,text,(x,y+h),font,1,(45,63,88),2)
                       
                  cv2.imshow('LookLikeAnimal',imgOrg)
                  if users[1]==text:
                        
                       cv2.imshow("img",cv2.resize(face_33[11],(100,100)))
                  if users[2]==text:
                       cv2.imshow("img",cv2.resize(face_44[18],(100,100)))
                  if users[0]==text:
                       cv2.imshow("img",cv2.resize(face_11[18],(100,100)))
                  if users[3]==text:
                       cv2.imshow("img",cv2.resize(face_55[18],(100,100)))
                  if users[4]==text:
                       cv2.imshow("img",cv2.resize(face_66[18],(100,100)))
                  if users[5]==text:
                       cv2.imshow("img",cv2.resize(face_77[18],(100,100)))
                  if users[6]==text:
                       cv2.imshow("img",cv2.resize(face_88[18],(100,100)))
                  if users[7]==text:
                       cv2.imshow("img",cv2.resize(face_99[18],(100,100)))
              
             else:
                  capture.set(cv2.CAP_PROP_POS_FRAMES,0)
        
             
             if cv2.waitKey(10)==27:
                  break
        capture.release()
        cv2.destroyAllWindows()
    def facemask(self):
        
        s_img = cv2.imread(self.my_absolute_dirpath+"\mask_1.png",-1)
        capture = cv2.VideoCapture(0)
        
        while True:
            ret, l_img = capture.read()
            gray = cv2.cvtColor(l_img, cv2.COLOR_BGR2GRAY)
            faces = self.dataset.detectMultiScale(gray, 1.2)
            if len(faces) > 0:
               
                # For Mask
                x_offset = faces[0][0]
                y_offset = faces[0][1]
        
                y1, y2 = y_offset, y_offset + s_img.shape[0]
                x1, x2 = x_offset, x_offset + s_img.shape[1]
        
                alpha_s = s_img[:, :, 3] / 255.0
                alpha_l = 1.0 - alpha_s
        
                for c in range(0, 3):
                    l_img[y1:y2, x1:x2, c] = (alpha_s * s_img[:, :, c] + alpha_l * l_img[y1:y2, x1:x2, c])
        
                cv2.imshow('filter',l_img)
            if cv2.waitKey(1) == 27:
                break
        
        capture.release()
        cv2.destroyAllWindows()
    def facemask3(self):
        s_img = cv2.imread(self.my_absolute_dirpath+"\cap_11.png",-1)
        capture = cv2.VideoCapture(0)
        
        while True:
            ret, l_img = capture.read()
            gray = cv2.cvtColor(l_img, cv2.COLOR_BGR2GRAY)
            faces = self.dataset.detectMultiScale(gray, 1.2)
            if len(faces) > 0:
                # For Cap
                x_offset = faces[0][0] - 15
                y_offset = faces[0][1] - s_img.shape[1] + 20
        
                y1, y2 = y_offset, y_offset + s_img.shape[0]
                x1, x2 = x_offset, x_offset + s_img.shape[1]
        
                alpha_s = s_img[:, :, 3] / 255.0
                alpha_l = 1.0 - alpha_s
        
                for c in range(0, 3):
                    l_img[y1:y2, x1:x2, c] = (alpha_s * s_img[:, :, c] + alpha_l * l_img[y1:y2, x1:x2, c])
        
                cv2.imshow('cap',l_img)
            if cv2.waitKey(1) == 27:
                break
        
        capture.release()
        cv2.destroyAllWindows()


    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600; color:#a6a6a6;\">Mirror Mirror</span></p></body></html>"))
        self.label_2.setText(_translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; color:#a81f66;\">Tell me who is beautiful</span></p></body></html>"))
        self.celebrity.setToolTip(_translate("Dialog", "Match your face with celebrity"))
        self.celebrity.setText(_translate("Dialog", "CelebrityLookLike"))
        self.animal.setToolTip(_translate("Dialog", "Match Your face with Animal"))
        self.animal.setText(_translate("Dialog", "AnimalLookLike"))
        self.label_3.setText(_translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt;\">Choose your Filter</span></p></body></html>"))
        self.mask.setToolTip(_translate("Dialog", "click to see mask in your face"))
        self.mask.setText(_translate("Dialog", "MaskFilter"))
        self.cap.setToolTip(_translate("Dialog", "Click to see cap on your head"))
        self.cap.setText(_translate("Dialog", "CapFilter"))
        self.label_4.setText(_translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt;\">Check Your face Match</span></p></body></html>"))
        self.label_5.setText(_translate("Dialog", "<html><head/><body><p><span style=\" color:#aaff00;\">Press Esc to exit from camera</span></p></body></html>"))
#import me_rc


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
