package only.java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;

public class CrearteNewPage extends JFrame {

	
	public JTextField userName;
	public JTextField phoneNumber;
	public JTextField email;
	public JTextField adhare;
	private JPasswordField passwordField;
	private JTextField confirmPassward;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrearteNewPage frame = new CrearteNewPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	   
	 
		public CrearteNewPage() {
			
	
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10, 135, 203, 20);
		getContentPane().add(passwordField);
		passwordField.setColumns(10);
		
		userName = new JTextField();
		userName.setBounds(10, 11, 203, 20);
		getContentPane().add(userName);
		userName.setColumns(10);
		
		phoneNumber = new JTextField();
		phoneNumber.setBounds(10, 42, 203, 20);
		getContentPane().add(phoneNumber);
		phoneNumber.setColumns(10);
		
		email = new JTextField();
		email.setBounds(10, 73, 203, 20);
		getContentPane().add(email);
		email.setColumns(10);
		
		adhare = new JTextField();
		adhare.setBounds(10, 104, 203, 20);
		getContentPane().add(adhare);
		adhare.setColumns(10);
		
		confirmPassward = new JTextField();
		confirmPassward.setBounds(10, 186, 203, 20);
		getContentPane().add(confirmPassward);
		confirmPassward.setColumns(10);
		
		JLabel lblConfirmPassward = new JLabel("confirm passward");
		lblConfirmPassward.setBounds(10, 166, 216, 14);
		getContentPane().add(lblConfirmPassward);
		
		JLabel lblUserName = new JLabel("user name");
		lblUserName.setBounds(243, 14, 120, 14);
		getContentPane().add(lblUserName);
		
		JLabel lblPhoneNumber = new JLabel("phone number");
		lblPhoneNumber.setBounds(243, 45, 109, 14);
		getContentPane().add(lblPhoneNumber);
		
		JLabel lblEmailId = new JLabel("email ID");
		lblEmailId.setBounds(243, 76, 46, 14);
		getContentPane().add(lblEmailId);
		
		JLabel lblAddareNumber = new JLabel("Addare number");
		lblAddareNumber.setBounds(243, 107, 130, 14);
		getContentPane().add(lblAddareNumber);
		
		JLabel lblPassward = new JLabel("passward");
		lblPassward.setBounds(243, 138, 46, 14);
		getContentPane().add(lblPassward);
		
		JLabel label = new JLabel("");
		label.setForeground(Color.RED);
		label.setFont(new Font("Tahoma", Font.PLAIN, 12));
		label.setBounds(243, 189, 170, 17);
		getContentPane().add(label);
		
		
	   
		JButton btnSubmit = new JButton(" next and otp");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					 	String p1 = String.valueOf(passwordField.getPassword());
						String name =userName.getText();
						String emailId = email.getText();
						String p2 =confirmPassward.getText();	
						String s = phoneNumber.getText();
						String a = adhare.getText();
						Long phone= Long.parseLong(s);
						final Long adhareId = Long.parseLong(a);
	
						new CollectData(name,emailId,phone,adhareId,p2);
						
				Pattern p4= Pattern.compile("(0/91)?[7-9][0-9]{9}");
				Pattern p3= Pattern.compile("[0-9]{12}");
				
				Matcher m = p4.matcher(s);
				Matcher m1 = p3.matcher(a);
				if(m.find() && m.group().equals(s)) {
					if(m1.find() && m1.group().equals(a)) {
						if(p1.equals(p2) ) {
							
							dispose();
							CreateNewPage2 cnp = new CreateNewPage2();
							cnp.setVisible(true);
							SendEmail.sendmain(emailId);
							}
							else {
								label.setText("please kindly enter correct value");
							}
						
						}
					else {
						label.setText("Adhare number format XXXXxxxxXXXX");
					}
					
					
					}
				else {
					label.setText("Mobile number format XXxxXXxxXX");
				}
				
			
			}catch(NumberFormatException ne) {
				JOptionPane.showMessageDialog(null,ne);
			}}}
		);
		btnSubmit.setBounds(10, 217, 120, 23);
		getContentPane().add(btnSubmit);
		
		JButton btnReset = new JButton("back");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			LoginPage p = new	LoginPage();
				p.frame.setVisible(true);
				dispose();
			}
			
		});
		btnReset.setBounds(161, 217, 89, 23);
		getContentPane().add(btnReset);
		}
		
}
