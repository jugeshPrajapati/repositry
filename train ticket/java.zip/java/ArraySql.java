package only.java;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
public class ArraySql {
	private static String url = "jdbc:sqlite:C:\\Users\\juges\\Desktop\\DatabaseSqlite\\UserAccount.db";
	private static Connection conn =null;
	private static Statement stmt = null;
	public static List<String> b= new ArrayList<>();
	public static List<String> b2= new ArrayList<>();
	public static List<String> b3= new ArrayList<>();
public static Connection userlogin() {
		try{	conn=DriverManager.getConnection(url);
		
		conn.setAutoCommit(false);
		stmt=conn.createStatement();
		String sql = "select *  from [Major junction]";
		ResultSet rss = stmt.executeQuery(sql);
		String names = null;
		while(rss.next()) {
		      names = rss.getString(1);
			  b.add(names);		}
		conn.commit();stmt.close();conn.close();
		return conn;
	}catch(SQLException e) {
		System.err.println(e.getMessage());
		int e1=e.getErrorCode();
		if (e1 == 19) {
			JOptionPane.showMessageDialog(null,"this email exist");
		}
	return null;	}}
public static void junctions(Object station1,Object station2) {
	try{	conn=DriverManager.getConnection(url);
		conn.setAutoCommit(false);
		stmt=conn.createStatement();
		String sql = "select *  from [Major junction] where Junction = '"+station1+"'";
		ResultSet rs = stmt.executeQuery(sql);
		String train,name = null;
		String[] t1 = null,t2 = null;
		while(rs.next()) {
			  train = rs.getString(2);
		      t1 = train.split(",");} 
	sql = "select *  from [Major junction] where Junction = '"+station2+"'";
		 ResultSet rs2 = stmt.executeQuery(sql);
		while(rs2.next()) {
			 train = rs2.getString(2);
			 t2= train.split(",");	}
		for(String s1:t1) {
			for(String s2:t2) {
				if(s1.equals(s2)) {
			    b3.add(s1);}}}
		conn.commit();
		stmt.close();
		conn.close();
	}catch(SQLException e) {
		System.err.println(e.getMessage());
		int e1=e.getErrorCode();
		if (e1 == 19) {
			JOptionPane.showMessageDialog(null,"this email exist");}
		}}}
