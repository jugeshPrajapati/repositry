package only.java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CreateNewPage2 extends JFrame{
private JTextField textField;
boolean updateDB;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateNewPage2 frame = new CreateNewPage2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public CreateNewPage2() {
	
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("UserName:\t"+CollectData.name1);
		lblName.setBounds(10, 11, 200, 14);
		getContentPane().add(lblName);
		
		JLabel lblPhoneNo = new JLabel("Phone Number:\t"+CollectData.phone1);
		lblPhoneNo.setBounds(10, 36, 189, 14);
		getContentPane().add(lblPhoneNo);
		
		JLabel lblEmail = new JLabel("Email:"+"\t"+CollectData.emailId1);
		lblEmail.setBounds(10, 70, 189, 14);
		getContentPane().add(lblEmail);
		
		JLabel lblAddar = new JLabel("Adhar Id: "+"\t"+CollectData.adhareId1);
		lblAddar.setBounds(10, 105, 189, 14);
		getContentPane().add(lblAddar);
		
		JLabel lblEnterOtp = new JLabel("enter otp");
		lblEnterOtp.setBounds(10, 130, 189, 14);
		getContentPane().add(lblEnterOtp);
		
		textField = new JTextField();
		textField.setBounds(10, 155, 86, 20);
		getContentPane().add(textField);
		
		textField.setColumns(10);
		
		JButton btnOk = new JButton("ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String otp1 = textField.getText();
				System.out.println(SendEmail.otp+"in createNewPage");
				if (otp1.equals(SendEmail.otp)) {
					CollectData.call();
					CollectData.loginUser(true);
						
					new LoginPage().frame.setVisible(true);
					dispose();
				}
			}
		});
		btnOk.setBounds(10, 186, 89, 23);
		getContentPane().add(btnOk);
		
		JButton btnBack = new JButton("edit");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				CrearteNewPage np = new CrearteNewPage();
				np.setVisible(true);
				dispose();
			}
		});
		btnBack.setBounds(110, 186, 89, 23);
		getContentPane().add(btnBack);
		
		JButton btnCancle = new JButton("cancle");
	    btnCancle.addActionListener(new ActionListener(){
	    	public void actionPerformed(ActionEvent arg0) {
	    	new LoginPage().frame.setVisible(true);
	    	dispose();
	    	}
	    });
		btnCancle.setBounds(7, 227, 89, 23);
		getContentPane().add(btnCancle);
	}

}
