package only.java;

public class CollectData {
	static String name1, emailId1,p21;
	static Long phone1,adhareId1;
	static boolean login;
	public  CollectData(String name,String emailId,Long phone,Long adhareId,String p2){
	 CollectData.name1= name;
	  CollectData.emailId1 = emailId;
	 CollectData.phone1 = phone;
	 CollectData.adhareId1= adhareId;
	  CollectData.p21= p2;}
	public static void call( ) {
	System.out.println("useraccount has called");
	 UserAccountSql.userlogin(name1,phone1,emailId1,adhareId1,p21);}
	public static void loginUser(boolean t) {
		login=t;}}
