package only.java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LogePage extends JFrame{

	
	private JTextField textField_2;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogePage frame = new LogePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

		public LogePage() {
		
	    setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 11, 160, 20);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setBounds(195, 14, 46, 14);
		getContentPane().add(lblEmailId);
		
		passwordField = new JPasswordField();
		passwordField.setToolTipText("enter your Mytrain login passward\r\n");
		passwordField.setBounds(10, 42, 160, 20);
		getContentPane().add(passwordField);
		
		JLabel lblPassward = new JLabel("passward");
		lblPassward.setBounds(195, 45, 46, 14);
		getContentPane().add(lblPassward);
		
		JButton btnSubmit = new JButton("submit");
		btnSubmit.setBounds(10, 73, 68, 23);
		getContentPane().add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
			
		 UserAccountSql.userValidation(textField_2.getText(),passwordField.getText());
		 if(CollectData.login==true) {
		 new LoginPage().frame.setVisible(true);
		
			dispose();
		 }
			}
		});
			
		
		
		JButton btnCreateNew = new JButton("create new");
		btnCreateNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CrearteNewPage np = new CrearteNewPage();
				np.setVisible(true);
				dispose();
				
			}
		});
		btnCreateNew.setBounds(88, 73, 89, 23);
		getContentPane().add(btnCreateNew);
		
		JLabel lblPleaseFillCorrect = new JLabel("please fill correct information");
		lblPleaseFillCorrect.setBounds(10, 107, 231, 14);
		getContentPane().add(lblPleaseFillCorrect);
		
		JButton btnNewButton = new JButton("Forgot passward?");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(10, 145, 130, 23);
		getContentPane().add(btnNewButton);
	}
}
