package only.java;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
public class UserAccountSql {
	private static String url = "jdbc:sqlite:C:\\Users\\juges\\Desktop\\DatabaseSqlite\\UserAccount.db";
	private static Connection conn =null;
	private static Statement stmt = null;
	public static Connection userlogin(String name, Long phone ,String em,Long adhare,String pw ) {
	try{conn=DriverManager.getConnection(url);
		conn.setAutoCommit(false);
		stmt=conn.createStatement();
		if(CollectData.login==false) {
		String sql="insert into UserDetail([User name],PhoneNumber,Email,[Addhare Number],Passward)"+
		"values('"+name+"',"+phone+",'"+em+"',"+adhare+",'"+pw+"');";
		stmt.executeUpdate(sql);
		JOptionPane.showMessageDialog(null,"succesfully inserted");
		}
		else {
			JOptionPane.showMessageDialog(null,"succesfully updated");
			String sql="update UserDetail set [User name]='"+name+"',PhoneNumber="+phone+",[Addhare Number]="+adhare+",Passward='"+pw+"' where Email='"+em+"';";
		    stmt.executeUpdate(sql);}
		conn.commit();stmt.close();conn.close();return conn;
	}catch(SQLException e) {
		
		int e1=e.getErrorCode();
		if (e1 == 19) {
			JOptionPane.showMessageDialog(null,"this email exist");}		
		
		return null;}}
public static Connection  userValidation(String eml,String pwd) {
try {
	conn=DriverManager.getConnection(url);
	conn.setAutoCommit(false);
	stmt=conn.createStatement();
	String sql = "select *  from UserDetail where  Email = '"+eml+"' and Passward = '"+pwd+"'";
	ResultSet rs = stmt.executeQuery(sql);
	while(rs.next()) {
		System.out.print("login successfully");
		String name = rs.getString(1);
		String emailId = eml;
		Long phone = rs.getLong(2);
		Long adhareId = rs.getLong(4);
		String p2 = pwd;
		CollectData.loginUser(true);
		 new CollectData(name,emailId,phone,adhareId,p2);
	}
	conn.commit();stmt.close();conn.close();
	}catch(SQLException e) {
		JOptionPane.showMessageDialog(null,e);}
catch(NullPointerException e) {
	JOptionPane.showMessageDialog(null,e);}
return null;}
public static Connection passenger(String name,Long adhare,String gender,int age ) {
	try{conn=DriverManager.getConnection(url);
		
		conn.setAutoCommit(false);
		stmt=conn.createStatement();
		String sql="insert into Passenger([User name],[Adhaar Number],Age,Gender)"+
		"values('"+name+"',"+adhare+","+age+",'"+gender+"');";
		stmt.executeUpdate(sql);
		JOptionPane.showMessageDialog(null,"succesfully inserted");
		conn.commit();stmt.close();conn.close();return conn;
	}catch(SQLException e) {
		
		int e1=e.getErrorCode();
		if (e1 == 19) {
			JOptionPane.showMessageDialog(null,"this email exist");}		
		
		return null;}}
}
