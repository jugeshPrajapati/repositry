package only.java;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.ScrollPane;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.util.ListIterator;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
public class BookPage extends JFrame{
	
	private JPanel contentPane;
    public JTable table;
   
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookPage frame = new BookPage();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}}});}

	
	public BookPage() {
		
		
		setBounds(100, 100, 810, 445);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		JComboBox comboBox = new JComboBox();
		comboBox.setSize(219, 23);
		comboBox.setLocation(10, 12);
		getContentPane().add(comboBox);
		ListIterator<String> iterator= ArraySql.b3.listIterator();
		while(iterator.hasNext()) {
			comboBox.addItem(iterator.next());
		}
		comboBox.setSelectedItem(null);
		JButton btnNewButton = new JButton("back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LoginPage p = new	LoginPage();
				p.frame.setVisible(true);
				dispose();
			}});
		btnNewButton.setBounds(10, 170, 89, 23);
		getContentPane().add(btnNewButton);
		JSpinner spinner = new JSpinner(new SpinnerNumberModel(1,1,6,1));
		spinner.setBounds(10, 46, 57, 20);
		getContentPane().add(spinner);
		
		JLabel lblNumberOfPassanger = new JLabel("number of passanger");
		lblNumberOfPassanger.setBounds(77, 46, 152, 14);
		getContentPane().add(lblNumberOfPassanger);
	    DefaultTableModel model = new DefaultTableModel();
	    String[] columns = new String[]{"User Name","Adhaar Number","Age","Gender"};
	    JButton btnOk = new JButton("ok");
	    btnOk.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		int row =(int )spinner.getValue();
	    		System.out.print((String)comboBox.getSelectedItem());
	            model.setRowCount(row);
	    		model.setColumnCount(4);
	    		model.setColumnIdentifiers(columns);
	    		table.setModel(model);
	    	}});
	    
	    btnOk.setBounds(10, 85, 89, 23);
	    getContentPane().add(btnOk);
	    JScrollPane scrollPane_1 = new JScrollPane();
	    scrollPane_1.setBounds(311, 42, 452, 169);
	    getContentPane().add(scrollPane_1);
	    table = new JTable();
	    scrollPane_1.setViewportView(table);
	    table.setForeground(Color.YELLOW);
	    table.setBackground(Color.LIGHT_GRAY);
	    table.setModel(new DefaultTableModel(columns,5));
	    JButton btnNext = new JButton("next");
			btnNext.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						Document document = new Document(PageSize.A4,50,50,50,50);
					    PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("C:/Users/juges/Desktop/ml jan/TrainTickect.pdf"));
					    document.open();
					    Paragraph title =new Paragraph("tickect",FontFactory.getFont(FontFactory.COURIER,14,Font.BOLD,new CMYKColor(0,255,0,0)));
					 	//document.add(title);
					 	Chapter chapter1 =new Chapter(title,1);
					 	chapter1.setNumberDepth(0);
					    Section  section1 = chapter1.addSection(title);
						PdfPTable t=new PdfPTable(table.getColumnCount());
						LoginPage lp= new LoginPage();
						lp.comboBox.getSelectedItem();
						for (int jj=0; jj<table.getColumnCount();jj++) {
							PdfPCell c1 = new PdfPCell(new Phrase(table.getColumnName(jj)));
							t.addCell(c1);
						}
					int numerow = table.getRowCount();
					for (int i =0;i<numerow;i++) {
						for (int j=0; j<table.getColumnCount();j++) {
						 
							System.out.print(table.getValueAt(i,j).toString());
							t.addCell(table.getValueAt(i,j).toString());
						 
						}
					}
					Paragraph titles =new Paragraph("train name"+comboBox.getSelectedItem().toString());
					Paragraph titles1 =new Paragraph("start from"+LoginPage.comboBox.getSelectedItem().toString());
					Paragraph titles2 =new Paragraph("end at"+LoginPage.comboBox_1.getSelectedItem().toString());
					Paragraph titles3 =new Paragraph("time"+lp.dateChooser.getDateFormatString());
					section1.add(t);
					section1.add(titles);
					section1.add(titles1);
					section1.add(titles2);
					section1.add(titles3);
					document.add(section1);

					document.close(); 
					for (int i =0;i<numerow;i++) {
						String name =table.getValueAt(i,0).toString();
				     	String adhare1 =table.getValueAt(i,1).toString();
				     	Long adhare= Long.parseLong(adhare1);
				     	String age1 =table.getValueAt(i,2).toString();
				     	int age =Integer.parseInt(age1);
		                String gender =table.getValueAt(i,3).toString();
						//System.out.println(name+"/"+adhare+"/"+age+"/"+gender);
						
						UserAccountSql.passenger(name, adhare, gender, age);
					}
				
					}catch(Exception np) {
						
						JOptionPane.showMessageDialog(null,"\"please fill all cell and press enter button after filing cells\""+np);
						
					}}});
			btnNext.setBounds(10, 136, 89, 23);
			getContentPane().add(btnNext);
			
			JLabel lblPleaseFillAll = new JLabel("please fill all cell and press enter");
			lblPleaseFillAll.setBounds(330, 16, 318, 14);
			getContentPane().add(lblPleaseFillAll);
	}	
}
