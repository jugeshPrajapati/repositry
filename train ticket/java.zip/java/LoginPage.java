package only.java;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.Choice;
import com.toedter.calendar.JCalendar;
import com.toedter.components.JSpinField;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JYearChooser;
import com.toedter.calendar.JDateChooser;
import java.awt.Canvas;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ListIterator;
import java.awt.event.ActionEvent;
public class LoginPage {
    JFrame frame;
    JButton btnLogin;
    static JComboBox comboBox;
	static JComboBox comboBox_1 ;
	JDateChooser dateChooser;
	public static void main(String[] args) {
		EventQueue.invokeLater(
				new Runnable() {
			public void run() {
				try {
					LoginPage window = new LoginPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();}}});}
	public LoginPage() {
		initialize();	}
private void initialize() {
		ArraySql.userlogin();
		String timestamp = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
		String times = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
		frame = new JFrame();
		frame.setBounds(100, 100, 828, 458);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	    btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LogePage log = new LogePage();
				log.setVisible(true);
				frame.dispose();}});
		btnLogin.setBounds(10, 11, 89, 23);
		frame.getContentPane().add(btnLogin);
		JButton btnCreateNewAccount = new JButton("Create New Account");
		btnCreateNewAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CrearteNewPage cnp = new CrearteNewPage();
				cnp.setVisible(true);
				frame.dispose();}});
		btnCreateNewAccount.setHorizontalAlignment(SwingConstants.LEADING);
		btnCreateNewAccount.setBounds(10, 40, 188, 33);
		frame.getContentPane().add(btnCreateNewAccount);
    	JButton btnLogout = new JButton("LogOut");
		btnLogout.setBounds(109, 11, 89, 23);
		frame.getContentPane().add(btnLogout);
	    comboBox = new JComboBox();
		comboBox.setToolTipText("from \r\n");
		comboBox.setBounds(10, 84, 287, 20);
		frame.getContentPane().add(comboBox);
		ListIterator<String> iterators= ArraySql.b.listIterator();
		while(iterators.hasNext()) {
			comboBox.addItem(iterators.next());	}
		comboBox.setSelectedItem(iterators.equals(1));
	    comboBox_1 = new JComboBox();
		comboBox_1.setBounds(10, 115, 287, 20);
		frame.getContentPane().add(comboBox_1);
		ListIterator<String> iterator= ArraySql.b.listIterator();
		while(iterator.hasNext()) {
			comboBox_1.addItem(iterator.next());}
		comboBox_1.setSelectedItem(iterator.equals(1));
		JButton btnBookNow = new JButton("Book Now");
		btnBookNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArraySql.junctions(comboBox.getSelectedItem(), comboBox_1.getSelectedItem());
			BookPage book =new BookPage();
			book.setVisible(true);
			frame.dispose();
			}});
		btnBookNow.setBounds(10, 177, 89, 23);
		frame.getContentPane().add(btnBookNow);
	    dateChooser = new JDateChooser();
		dateChooser.setBounds(10, 146, 287, 20);
		frame.getContentPane().add(dateChooser);
		JLabel lblFrom = new JLabel("From");
		lblFrom.setBounds(356, 87, 46, 14);
		frame.getContentPane().add(lblFrom);
		JLabel lblTo = new JLabel("To");
		lblTo.setBounds(356, 121, 46, 14);
		frame.getContentPane().add(lblTo);
		JLabel lblDate = new JLabel("data");
		lblDate.setBounds(208, 152, 46, 14);
		frame.getContentPane().add(lblDate);
	
		JButton btnUser = new JButton("User");
		    btnUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			CrearteNewPage np = new CrearteNewPage();
			np.userName.setText(CollectData.name1);
			String a =CollectData.adhareId1.toString();
			np.adhare.setText(a);
			np.email.setText(CollectData.emailId1);
			np.email.setEnabled(false);
			np.phoneNumber.setText(CollectData.phone1.toString());
		   	np.setVisible(true);
			frame.dispose();}});
		btnUser.setBounds(208, 11, 89, 62);
		frame.getContentPane().add(btnUser);
		if(CollectData.login==true) {
			btnLogin.setEnabled(false);
			btnUser.setText(CollectData.name1);
			btnCreateNewAccount.setEnabled(false);
			btnUser.setEnabled(true);
			btnBookNow.setEnabled(true);
			btnLogout.setEnabled(true);
			}
		else {
			btnUser.setEnabled(false);
			btnBookNow.setEnabled(false);
			btnLogout.setEnabled(false);
		}
		
		JLabel lblCheckTrainLocation = new JLabel("Check Train Location");
		lblCheckTrainLocation.setBounds(10, 211, 135, 19);
		frame.getContentPane().add(lblCheckTrainLocation);
		
		JButton btnStatus = new JButton("status");
		btnStatus.setBounds(123, 209, 89, 23);
		frame.getContentPane().add(btnStatus);
		
		JLabel lblDate_1 = new JLabel("Date : "+timestamp);
		lblDate_1.setBounds(356, 15, 125, 14);
		frame.getContentPane().add(lblDate_1);
		
		JLabel lblCurrentTime = new JLabel("Time : "+times);
		lblCurrentTime.setBounds(356, 49, 125, 14);
		frame.getContentPane().add(lblCurrentTime);
	}
}
