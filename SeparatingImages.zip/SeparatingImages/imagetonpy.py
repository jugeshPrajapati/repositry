import numpy as np
import cv2,pickle
import os
facelist= []
NotComplete=True
while NotComplete:
    for  file in os.listdir("C:/Users/juges/Desktop/image Processing/imageRecord/turtul"):
         if  file.endswith(".jfif") or file.endswith(".jpg") or file.endswith(".png"):
              image = os.path.join("C:/Users/juges/Desktop/image Processing/imageRecord/turtul",file)
    
             
              img = cv2.imread( image ,cv2.IMREAD_GRAYSCALE  )
    
              my_face  = cv2.resize(img,(50,50))
              if len(facelist)<20:
                   
                   
                  facelist.append(my_face)
                  print(len(facelist),image)
         if cv2.waitKey(1) ==27 or len(facelist) >= 20:
             
              NotComplete=False
              break
facelist  = np.asarray(facelist)
filename = input('enter file name')
np.save(filename+'.npy',facelist)
cv2.destroyAllWindows()
