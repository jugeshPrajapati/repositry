#import library
import numpy as np,cv2,os
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
#import images or npy file or data
Scalify = StandardScaler()
my_absolute_dirpath = os.path.abspath(os.path.dirname(__file__))
face_11 =  np.load(my_absolute_dirpath+'\\npyFiles\simplecatface20.npy')
face_33 =  np.load(my_absolute_dirpath+'\\npyFiles\simpledogface20.npy')
face_44 =  np.load(my_absolute_dirpath+'\\npyFiles\simplepigeonface20.npy')
face_55 =  np.load(my_absolute_dirpath+'\\npyFiles\Bear20.npy')
face_66 =  np.load(my_absolute_dirpath+'\\npyFiles\Donkey20.npy')
face_77 =  np.load(my_absolute_dirpath+'\\npyFiles\Fish20.npy')
face_88 =  np.load(my_absolute_dirpath+'\\npyFiles\Lion20.npy')
face_99 =  np.load(my_absolute_dirpath+'\\npyFiles\Turtel20.npy')
#reshapeing
face_1 = face_11.reshape(20,-1)
face_3 = face_33.reshape(20,-1)
face_4 = face_44.reshape(20,-1)
face_5 = face_55.reshape(20,-1)
face_6 = face_66.reshape(20,-1)
face_7 = face_77.reshape(20,-1)
face_8 = face_88.reshape(20,-1)
face_9 = face_99.reshape(20,-1)
#final dataset or features
faceData = np.concatenate([face_1,face_3,face_4,face_5,face_6,face_7,face_8,face_9])
#label or y
label = np.zeros((faceData.shape[0],1))
label[20:40,:] = 1.0
label[40:60,:] = 2.0
label[60:80,:] = 3.0
label[80:100,:] = 4.0
label[100:120,:] = 5.0
label[120:140,:] = 6.0
label[140:160,:] = 7.0

X,Y = faceData[:,:],label[:,-1]
#train the data
X_Train,X_Test ,Y_Train,Y_Test = train_test_split(X,Y,test_size=0.2,shuffle=True,random_state=42)

#normalization and scaling
X_Train_prepared =Scalify.fit_transform(X_Train)
#fiting in classifier model
sgd_clf =SGDClassifier(random_state=42)
sgd_clf.fit(X_Train_prepared,Y_Train)

#testing on mix dataset
facelist=[]

for  file in os.listdir("C:/Users/juges/Desktop/image Processing/imageRecord/MixAnimal"):
         if  file.endswith(".jfif") or file.endswith(".jpg") or file.endswith(".png"):
              image = os.path.join("C:/Users/juges/Desktop/image Processing/imageRecord/MixAnimal",file)
    
             
              img = cv2.imread( image ,cv2.IMREAD_GRAYSCALE  )
    
              my_face  = cv2.resize(img,(50,50))
            
                   
              facelist.append(my_face)
             # print(len(facelist),image)
         if cv2.waitKey(1) ==27:
             
              break
facelist  = np.asarray(facelist)
#print(facelist.shape)
facelist1 = facelist.reshape(facelist.shape[0],-1)
#print(facelist.shape)
X_Test_prepared =Scalify.fit_transform(facelist1)
Y_Pred = sgd_clf.predict(X_Test_prepared)
#print(Y_Pred)
cv2.destroyAllWindows()

#print(np.unique(label))
#print(len(np.unique(label)))
#print(len(facelist))
#print(len(Y_Pred))

#storing in their kind
for i in range(len(np.unique(label))):
 #   print(i)
    if not os.path.isdir(my_absolute_dirpath+"/"+str(i)):
        os.mkdir(my_absolute_dirpath+"/"+str(i))
    for j in range(len(facelist)):

         if Y_Pred[j]==i:
            # print("in"+str(i)+":"+str(facelist[j])
             path=my_absolute_dirpath+"/"+str(i)+"/"+str(j)+".jpg"
             #print(path+"/"+str(j)+".jpg")
             cv2.imwrite(path,cv2.resize(facelist[j],(50,50)))
            


cv2.destroyAllWindows()





